
step 1: open the zip file and extract its
step 2: upload the excel file named "carss.csv" to your comiler like jupyter 
step 3: install the libraries called(numpy,pandas,matplotlib.pyplot,seaborn,scipy).
        example -pip install numpy..
step 4: open the file called "code" this contain the project code,copy that and run in your python compiler.
step 5: you can observe the output.

